package com.journaldev.files;

import java.io.IOException;

public class Main 
{
	public static void main(String[] args) throws IOException
	{
		Columns nasc = new Columns();
		HTML html = new HTML();
		
		html.getNumOfColFromUser(nasc);  // read input number from user
		html.createHTMLFileAndWrite(nasc); // // Create CSS File 
		html.createCssFileAndPrintClassColor(nasc); // Create HTML File 
		
		System.out.println("DONE! :)");
	}
}
