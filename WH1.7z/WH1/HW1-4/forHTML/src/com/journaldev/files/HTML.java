package com.journaldev.files;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Scanner;


public class HTML 
{

	public  void getNumOfColFromUser(Columns col)
	{
		Scanner in = new Scanner(System.in);
		int numberFromUser;

		do
		{
			System.out.println("Please Wirte a number between 1-50 and press enter");
			numberFromUser = in.nextInt();
		}while ( !isValid( numberFromUser) );

		col.setNumOfCol(numberFromUser) ;
		col.setsizeOfCol((double)100/col.getNumOfCol());

		in.close();
	}

	// checking input valid
	private boolean isValid(int numberFromUser){
		if(numberFromUser > 50 || numberFromUser  < 1){
			System.out.println("Wrong number!");
			return false;
		}  else return true;
	}

	public  void createCssFileAndPrintClassColor(Columns col) throws FileNotFoundException, UnsupportedEncodingException
	{
		PrintWriter writer = new PrintWriter("HW1-css4.css", "UTF-8");
		try{	
			writer.println(".divAll {");
			writer.println("	width: 100%;");
			writer.println("	height: 100%;");
			writer.println("}");

			writer.println(".blue {");
			writer.println("	width: " + col.getsizeOfCol() + "%;");
			writer.println("	height: 100%;" );
			writer.println("	background-color: blue;");
			writer.println("	float: left;");
			writer.println("}");

			writer.println(".red {");
			writer.println("	width: " + col.getsizeOfCol() + "%;");
			writer.println("	height: 100%;" );
			writer.println("	background-color: red;");
			writer.println("	float: left;");
			writer.println("}");

			writer.println(".green {");
			writer.println("	width: " + col.getsizeOfCol() + "%;");
			writer.println("	height: 100%;" );
			writer.println("	background-color: green;");
			writer.println("	float: left;");
			writer.println("}");
		}finally
		{
			writer.close();
		}
	}



	public  void createHTMLFileAndWrite(Columns col) throws FileNotFoundException, UnsupportedEncodingException 
	{
		PrintWriter writer = new PrintWriter("HW1-4.html", "UTF-8");

		
			writer.println("<html>");
			writer.println("	<head>"  );
			writer.println("		<link rel=\"stylesheet\" type=\"text/css\" href=\"HW1-css4.css\">" );
			writer.println("	</head>");
			writer.println();
			writer.println("	<title>"+ "HW1-4"+ "</title>");
			writer.println("	<body>");

			printColumns(col,writer);

			writer.println("	</body>");
			writer.println("</html>");

			writer.close();
	}

	public static void printColumns(Columns col, PrintWriter writer)
	{
		//initialize 
		Boolean[] colors = new Boolean[3];
		Arrays.fill(colors, Boolean.FALSE);

		writer.println("		<div" + " class=\"divAll\"" + ">");

		// print columns
		for(int i=0; i < col.getNumOfCol(); i++)
		{
			if (colors[2] == true)
			{
				Arrays.fill(colors, Boolean.FALSE);
			}

			if (colors[0] == false)
			{
				writer.println("				<div" + " class=\"blue\"" + ">" + "</div>");
				colors[0] = true;
				continue;
			}

			else if (colors[1] == false)
			{
				writer.println("				<div" + " class=\"red\"" + ">" + "</div>");
				colors[1] = true;
				continue;
			}

			else if (colors[2] == false)
			{
				writer.println("				<div" + " class=\"green\"" + ">" + "</div>");
				colors[2] = true;
				continue;
			}
		}
		writer.println("		</div>");
	}
}

