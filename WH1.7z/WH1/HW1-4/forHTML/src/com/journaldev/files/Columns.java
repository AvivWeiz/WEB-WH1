package com.journaldev.files;

public class Columns
{
	private int NumOfCol;
	private double sizeOfCol;


	public Columns(  ) 
	{
		this.NumOfCol = 0;
		this.sizeOfCol = 0;
	}


	public int getNumOfCol()
	{
		return( this.NumOfCol );
	}

	public void setNumOfCol( int n )
	{
		this.NumOfCol = n;
	}

	public double getsizeOfCol()
	{
		return( this.sizeOfCol );
	}

	public void setsizeOfCol( double n )
	{
		this.sizeOfCol = n;
	}


}
